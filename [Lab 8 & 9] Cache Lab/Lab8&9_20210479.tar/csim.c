/* student id: 20210479
 * student name: Lee Juhyeon
 * login id: lanthanum14 */

#include "cachelab.h"

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <string.h>

/* struct for implementing cache structure */
typedef struct
{
    int valid; //valid variable
    unsigned long long int tag; //tag bits
    int lruCnt; //checking the most recent used time
} line;

int lru = 0;

/* global variables set by command line + subsequently set according to them */
int vb = 0; //checking if command has v option
int s = 0;
int b = 0;
int E = 0;
int S = 0;
int B = 0;

/* counters for printing summary */
int hit_count = 0;
int miss_count = 0;
int eviction_count = 0;

/* other necessary global variables */
line** cache; //one for simulating cache
FILE* traceFile = NULL; //one for trace file
char* trace = NULL; //one for trace file name
int c = 0; //one for getopt function

/* necessary functions */
void printMan(char *argv[]); //print usage when option '-h' is typed or some parameters are missing
int parsingData(int argc, char *argv[]); //parsing command line with 'getopt' function
void newCache(); //allocate and initiate cache variable
void deleteCache(); //free cache variable
void findAddr(unsigned long long int addr); //access and find datas from cache

int main(int argc, char* argv[])
{  
    char mode; //a variable for storing each operation from trace file
    unsigned long long int addr; //a variable for storing each address from trace file
    int byte; //a variable for storing each instruction's size

    if (!parsingData(argc, argv))
    {
        newCache(); //allocate cache if parsingData is valid

        traceFile = fopen(trace, "r");

        if(traceFile != NULL)
        {
            while(fscanf(traceFile, " %c %llx,%d", &mode, &addr, &byte) != EOF) //during the end of "traceFile"
            {
                if (vb && (mode != 'I')) { printf("%c %llu,%d ", mode, addr, byte); }
            
                switch(mode)
                {
                    case 'L':
                        findAddr(addr);
                        break;
                    case 'S':
                        findAddr(addr);
                        break;
                    case 'M':
                        findAddr(addr);
                        findAddr(addr);
                        break;
                    default: //we don't have to read "I"
                        break;
                }

                if (vb && (mode != 'I')) { printf("\n"); }
            }

            printSummary(hit_count, miss_count, eviction_count);
            fclose(traceFile);
        }

        deleteCache();
        return 0;
    }
    
    else
    {
        return -1;
    }
}

void printMan(char *argv[]) 
{
    printf("Usage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\nOptions:\n", argv[0]);
    printf("  -h         Print this help message.\n");
    printf("  -v         Optional verbose flag.\n");
    printf("  -s <num>   Number of set index bits.\n");
    printf("  -E <num>   Number of lines per set.\n");
    printf("  -b <num>   Number of block offset bits.\n");
    printf("  -t <file>  Trace file.\n\nExamples:\n");
    printf("  linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
    printf("  linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
}

int parsingData(int argc, char *argv[])
{  
    int cnt = 0; //a variable for checking if valid value has entered
  
    while((c = getopt(argc, argv, "hvs:E:b:t:")) != -1) //while getopt function gets all of the parameters from the command line
    {
        switch(c)
        {
            case 'v':
                vb = 1;
                break;
            case 's':
                s = atoi(optarg);
		if (s > 0) { cnt++; }
                S = 1 << s; //S = 2^s
                break;
            case 'E':
                E = atoi(optarg);
		if (E > 0) { cnt++; }
                break;
            case 'b':
                b = atoi(optarg);
		if (b > 0) { cnt++; }
                B = 1 << b; //B = 2^b
                break;
            case 't':
                trace = (char*) malloc(sizeof(char) * (strlen(optarg) + 1));
                trace = optarg;
                break;
            case 'h':
                printMan(argv);
                return 1;
            default:
                printMan(argv);
                return 1;
        }
    }

    /* checking if there are all required arguments or not */
    if (s < 0 || E < 0 || b < 0 || (trace == NULL)) //when all arguments are valid, then store that values to real global variables
    {         
	if ((trace == NULL) && cnt > 2) { printf("./csim: option requires an argument -- \'t\'\n"); printMan(argv); }

        else if ((trace != NULL) && cnt > 2) { printf("%s: No such file or directory\n", trace); }

        else
        {
            printf("%s: Missing required command line argument\n", argv[0]);
            printMan(argv);
        }

        return 1;
    }

    return 0;                              
}

void newCache()
{
    int i = 0, j = 0; //variables for iteration

    cache = (line**)malloc(sizeof(line*) * S);

    for (i = 0; i < S; i++)
    {
        cache[i] = (line*)malloc(sizeof(line) * E);

        for (j = 0; j < E; j++)
        {
            cache[i][j].valid = 0;
            cache[i][j].tag = 0;
            cache[i][j].lruCnt = 0;
        }
    }
}

void deleteCache()
{
    int i = 0; //a variable for iteration

    for(i = 0; i < S; i++)
    {
        free(cache[i]);
    }

    free(cache);
}

void findAddr(unsigned long long int addr)
{
    int i = 0; //a variable for iteration
    unsigned long long int targetTag = addr >> (s + b); //target tag bit from address
    int targetSet = (int)((addr >> b) - (targetTag << s)); //target set index from address
    int ifHit = -1, ifMiss = -1, ifEvic = -1; //variables for checking conditions

    /* hit situation */
    for (i = 0; i < E; i++)
    {
        if (cache[targetSet][i].valid)
        {
            if (cache[targetSet][i].tag == targetTag)
            {
                if (vb) { printf(" hit"); }
                hit_count++;
                ifHit = i;
                cache[targetSet][i].lruCnt = lru;
                break;
            }
        }
    }

    /* ETC situation */
    if (ifHit < 0)
    {
        /* miss situation */
        if (vb) { printf(" miss"); }
        miss_count++;

        for (i = 0; i < E; i++)
        {
            if (!cache[targetSet][i].valid)
            {
                ifMiss = i;
                break;
            }
        }

        /* if there is empty line */
        if (ifMiss >= 0)
        {
            cache[targetSet][ifMiss].valid = 1;
            cache[targetSet][ifMiss].tag = targetTag;
            cache[targetSet][ifMiss].lruCnt = lru;
        }

        /* eviction situation */
        else
        {
            if (vb) { printf(" eviction"); }
            eviction_count++;

            int lr = cache[targetSet][0].lruCnt; //storing least recent one
            ifEvic = 0;
            
            for (i = 0; i < E; i++)
            {
                if (cache[targetSet][i].lruCnt < lr)
                {
                    lr = cache[targetSet][i].lruCnt;
                    ifEvic = i;
                }
            }

            cache[targetSet][ifEvic].valid = 1;
            cache[targetSet][ifEvic].tag = targetTag;
            cache[targetSet][ifEvic].lruCnt = lru;
        }
    }

    lru++;
}
