/* student id: 20210479 
 * student name: Lee JuHyeon
 * login ID: lanthanum14  */

/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int i, j; //variables for iteration
    int maxRow = 0, maxCol = 0; //variables for storing matrix size
    int t0, t1, t2, t3, t4, t5, t6, t7; //variables for temporary storage

    if (M == 32) //optimization for case 1 (M = 32, N = 32)
    {
        /* reading 8 elements in each loop for utilizing spatial locality */
        for (maxRow = 0; maxRow < M; maxRow += 8)
        {
            for (maxCol = 0; maxCol < M; maxCol += 8)
            {
                for (i = 0; i < 8; i++)
                {
                    t0 = A[maxRow + i][maxCol + 0];
                    t1 = A[maxRow + i][maxCol + 1];
                    t2 = A[maxRow + i][maxCol + 2];
                    t3 = A[maxRow + i][maxCol + 3];
                    t4 = A[maxRow + i][maxCol + 4];
                    t5 = A[maxRow + i][maxCol + 5];
                    t6 = A[maxRow + i][maxCol + 6];
                    t7 = A[maxRow + i][maxCol + 7];

                    B[maxCol + 0][maxRow + i] = t0;
                    B[maxCol + 1][maxRow + i] = t1;
                    B[maxCol + 2][maxRow + i] = t2;
                    B[maxCol + 3][maxRow + i] = t3;
                    B[maxCol + 4][maxRow + i] = t4;
                    B[maxCol + 5][maxRow + i] = t5;
                    B[maxCol + 6][maxRow + i] = t6;
                    B[maxCol + 7][maxRow + i] = t7;
                }
            }
        }
    }

    else if (M == 64) //optimization for case 2 (M = 64, N = 64)   
    {
        for (maxRow = 0; maxRow < M; maxRow += 4)
        {
            for (maxCol = 0; maxCol < M; maxCol += 4)
            {
                /* storing the first line in advance (this will be the first line of array B) */
                /* additional storage with t3, t4 to utilize spatial locality */
                t0 = A[maxRow][maxCol];
                t1 = A[maxRow + 1][maxCol];
                t2 = A[maxRow + 2][maxCol];
                t3 = A[maxRow + 2][maxCol + 1];
                t4 = A[maxRow + 2][maxCol + 2];

                /* subsitution of variables in B[maxCol + 3][] */
                B[maxCol + 3][maxRow] = A[maxRow][maxCol + 3];
                B[maxCol + 3][maxRow + 1] = A[maxRow + 1][maxCol + 3];
                B[maxCol + 3][maxRow + 2] = A[maxRow + 2][maxCol + 3];

                /* subsitution of variables in B[maxCol + 2][] */
                B[maxCol + 2][maxRow] = A[maxRow][maxCol + 2];
                B[maxCol + 2][maxRow + 1] = A[maxRow + 1][maxCol + 2];
                B[maxCol + 2][maxRow + 2] = t4;
                t4 = A[maxRow + 1][maxCol + 1]; //using spatial locality
                
                /* subsitution of variables in B[maxCol + 1][] */
                B[maxCol + 1][maxRow] = A[maxRow][maxCol + 1];
                B[maxCol + 1][maxRow + 1] = t4;
                B[maxCol + 1][maxRow + 2] = t3;

                /* subsitution of variables in B[maxCol][] */
                B[maxCol][maxRow] = t0;
                B[maxCol][maxRow + 1] = t1;
                B[maxCol][maxRow + 2] = t2;

                /* fill in unperformed parts in array B: line of [maxRow + 3][] in array A */
                B[maxCol][maxRow + 3] = A[maxRow + 3][maxCol];
                B[maxCol + 1][maxRow + 3] = A[maxRow + 3][maxCol + 1];
                B[maxCol + 2][maxRow + 3] = A[maxRow + 3][maxCol + 2];

                /* fill in the final one avoiding cache eviction */
                t0 = A[maxRow + 3][maxCol + 3];
                B[maxCol + 3][maxRow + 3] = t0;
            }
        }
    }

    else //optimization for case 3 (M = 61, N = 67)
    {
        for (maxRow = 0; maxRow < N; maxRow += 16)
        {
            for (maxCol = 0; maxCol < M; maxCol += 16)
            {
                for (i = maxRow; (i < maxRow + 16) && (i < N); i++)
                {
                    for (j = maxCol; (j < maxCol + 16) && (j < M); j++)
                    {
                        if (i == j)
                        {
                            t0 = i;
                            t1 = A[i][j];
                        }

                        else
                        {
                            B[j][i] = A[i][j];
                        }
                    }

                    if (maxRow == maxCol)
                    {
                        B[t0][t0] = t1;
                    }
                }
            }
        }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

